﻿import { useState, useEffect, useMemo, useRef, useCallback } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { type ColumnDef, type SortingState } from '@tanstack/react-table';
import { useSearchParams } from 'react-router-dom';
import { Plus, Bell, Phone, Mail, MessageSquare, Users, Calendar, AlertTriangle } from 'lucide-react';
import { toastSuccess, toastError } from '../../lib/toast';

import { useAuth } from '../../contexts/AuthContext';
import { prospectRepository, prospectInteracaoRepository } from '../../services/repositories';
import { prospectSchema, type Prospect, type ProspectInput, type ProspectInteracao } from '../../domain/types';
import { formatCurrency } from '../../domain/calculations';
import { DataTable, CurrencyCell, StatusBadge, ActionButtons } from '../../components/shared/DataTable';
import { Modal, ConfirmDialog, PageHeader, PageSkeleton } from '../../components/ui';
import { Input, Select, TextArea } from '../../components/shared/FormFields';
import SavedViewsControl from '../../components/saved-views/SavedViewsControl';
import { type SavedViewSnapshot } from '../../lib/savedViews';
import { emitDataInvalidation, subscribeDataInvalidation } from '../../lib/dataInvalidation';
import { saveProspectWithConversion } from '../../services/prospectConversionService';

const statusOptions = [
  { value: 'novo', label: 'Novo' },
  { value: 'em_contato', label: 'Em Contato' },
  { value: 'qualificado', label: 'Qualificado' },
  { value: 'proposta', label: 'Proposta' },
  { value: 'ganho', label: 'Ganho' },
  { value: 'perdido', label: 'Perdido' },
];

const origemOptions = [
  { value: 'indicacao', label: 'Indicação' },
  { value: 'liberta', label: 'Liberta' },
  { value: 'linkedin', label: 'LinkedIn' },
  { value: 'evento', label: 'Evento' },
  { value: 'site', label: 'Site' },
  { value: 'cold_call', label: 'Cold Call' },
  { value: 'outros', label: 'Outros' },
];

const tipoOptions = [
  { value: 'captacao_liquida', label: 'Captação Líquida' },
  { value: 'transferencia_xp', label: 'Transferência XP' },
];

const interacaoTipoOptions = [
  { value: 'ligacao', label: 'Ligação' },
  { value: 'reuniao', label: 'Reunião' },
  { value: 'email', label: 'Email' },
  { value: 'whatsapp', label: 'WhatsApp' },
  { value: 'visita', label: 'Visita' },
  { value: 'outro', label: 'Outro' },
];

const interacaoIcons: Record<string, React.ReactNode> = {
  ligacao: <Phone className="w-4 h-4" />,
  reuniao: <Users className="w-4 h-4" />,
  email: <Mail className="w-4 h-4" />,
  whatsapp: <MessageSquare className="w-4 h-4" />,
  visita: <Calendar className="w-4 h-4" />,
  outro: <Bell className="w-4 h-4" />,
};

function isWonProspectStatus(status: Prospect['status'] | undefined): boolean {
  if (!status) return false;
  const normalized = status.toLowerCase().trim();
  return normalized === 'ganho' || normalized === 'won' || normalized === 'closedwon' || normalized === 'closed_won';
}

export default function ProspectsPage() {
  const { user } = useAuth();
  const [searchParams, setSearchParams] = useSearchParams();
  const [prospects, setProspects] = useState<Prospect[]>([]);
  const [interacoes, setInteracoes] = useState<ProspectInteracao[]>([]);
  const [loading, setLoading] = useState(true);
  const [modalOpen, setModalOpen] = useState(false);
  const [deleteModalOpen, setDeleteModalOpen] = useState(false);
  const [detalhesModalOpen, setDetalhesModalOpen] = useState(false);
  const [selectedProspect, setSelectedProspect] = useState<Prospect | null>(null);
  const [saving, setSaving] = useState(false);
  const [tableSearch, setTableSearch] = useState('');
  const [tableSorting, setTableSorting] = useState<SortingState>([]);
  const handledQueryRef = useRef<string | null>(null);

  const {
    register,
    handleSubmit,
    reset,
    watch,
    formState: { errors },
  } = useForm<ProspectInput>({
    resolver: zodResolver(prospectSchema),
    defaultValues: {
      status: 'novo',
      potencial: 0,
      probabilidade: 50,
    },
  });

  const loadData = useCallback(async () => {
    if (!user) return;

    try {
      setLoading(true);
      const [prospectsData, interacoesData] = await Promise.all([
        prospectRepository.getAll(user.uid),
        prospectInteracaoRepository.getAll(user.uid),
      ]);
      setProspects(prospectsData);
      setInteracoes(interacoesData);
    } catch (error) {
      console.error('Erro ao carregar dados:', error);
      toastError('Erro ao carregar dados');
    } finally {
      setLoading(false);
    }
  }, [user]);

  useEffect(() => {
    void loadData();
  }, [loadData]);

  useEffect(() => {
    return subscribeDataInvalidation(['prospects'], async () => {
      await loadData();
    });
  }, [loadData]);

  // Lembretes: prospects com proximo contato hoje ou atrasado
  const lembretes = useMemo(() => {
    const hoje = new Date().toISOString().split('T')[0];
    return prospects.filter((p) => p.proximoContato && p.proximoContato <= hoje && !['ganho', 'perdido'].includes(p.status));
  }, [prospects]);

  const statusWatch = watch('status');
  const realizadoValorWatch = watch('realizadoValor');
  const realizadoDataWatch = watch('realizadoData');
  const isWonSelected = isWonProspectStatus(statusWatch);

  const openModal = useCallback((prospect?: Prospect) => {
    if (prospect) {
      setSelectedProspect(prospect);
      reset(prospect);
    } else {
      setSelectedProspect(null);
      reset({
        nome: '',
        email: '',
        telefone: '',
        origem: '',
        status: 'novo',
        potencial: 0,
        potencialTipo: 'captacao_liquida',
        probabilidade: 50,
        proximoContato: '',
        proximoContatoHora: '',
        realizadoValor: 0,
        realizadoTipo: 'captacao_liquida',
        realizadoData: '',
        observacoes: '',
      });
    }
    setModalOpen(true);
  }, [reset]);

  const getSavedViewSnapshot = useCallback((): SavedViewSnapshot => {
    const firstSort = tableSorting[0];
    return {
      searchTerm: tableSearch,
      filters: {},
      sort: firstSort ? { id: firstSort.id, desc: firstSort.desc } : null,
    };
  }, [tableSearch, tableSorting]);

  const applySavedViewSnapshot = useCallback((snapshot: SavedViewSnapshot) => {
    setTableSearch(snapshot.searchTerm ?? '');
    setTableSorting(snapshot.sort ? [{ id: snapshot.sort.id, desc: snapshot.sort.desc }] : []);
  }, []);

  useEffect(() => {
    if (loading) return;

    const queryKey = searchParams.toString();
    if (handledQueryRef.current === queryKey) return;
    handledQueryRef.current = queryKey;

    const createParam = searchParams.get('create');
    const openParam = searchParams.get('open');
    if (!createParam && !openParam) return;

    const nextParams = new URLSearchParams(searchParams);
    let shouldReplace = false;

    if (createParam === '1') {
      openModal();
      nextParams.delete('create');
      shouldReplace = true;
    }

    if (openParam) {
      const target = prospects.find((prospect) => prospect.id === openParam);
      if (target) {
        setSelectedProspect(target);
        setDetalhesModalOpen(true);
      }
      nextParams.delete('open');
      shouldReplace = true;
    }

    if (shouldReplace) {
      setSearchParams(nextParams, { replace: true });
    }
  }, [loading, openModal, prospects, searchParams, setSearchParams]);

  const onSubmit = async (data: ProspectInput) => {
    if (!user) return;

    try {
      setSaving(true);
      const parsed = prospectSchema.parse(data);

      const isWon = isWonProspectStatus(parsed.status);
      const hasRealizedGate = Number(parsed.realizadoValor || 0) > 0 && Boolean(parsed.realizadoData);

      if (isWon && !hasRealizedGate) {
        toastError('Para status Ganho, informe Valor Realizado > 0 e Data Realizado.');
        return;
      }

      const result = await saveProspectWithConversion({
        prospectId: selectedProspect?.id,
        data: parsed,
      }, {
        ownerUid: user.uid,
      });

      if (selectedProspect?.id) {
        setProspects((prev) => prev.map((item) => (item.id === selectedProspect.id ? result.prospect : item)));
        if (result.prospect.converted) {
          toastSuccess('Prospect atualizado e conversao sincronizada com Cliente/Metas.');
        } else {
          toastSuccess('Prospect atualizado com sucesso!');
        }
      } else {
        setProspects((prev) => [...prev, result.prospect]);
        if (result.prospect.converted) {
          toastSuccess('Prospect criado e convertido em cliente.');
        } else {
          toastSuccess('Prospect criado com sucesso!');
        }
      }

      emitDataInvalidation(['prospects', 'clients', 'captacao', 'metas', 'dashboard']);

      setModalOpen(false);
      reset();
    } catch (error) {
      console.error('Erro ao salvar prospect:', error);
      if (error instanceof Error && error.message === 'PROSPECT_CONVERSION_REQUIREMENTS') {
        toastError('Para converter em cliente, status Ganho exige valor realizado > 0 e data preenchida.');
      } else {
        toastError('Erro ao salvar prospect');
      }
    } finally {
      setSaving(false);
    }
  };

  const handleDelete = async () => {
    if (!user || !selectedProspect?.id) return;

    try {
      setSaving(true);
      await prospectRepository.delete(selectedProspect.id, user.uid);
      setProspects((prev) => prev.filter((p) => p.id !== selectedProspect.id));
      toastSuccess('Prospect excluido com sucesso!');
      emitDataInvalidation(['prospects', 'clients', 'captacao', 'metas', 'dashboard']);
      setDeleteModalOpen(false);
      setSelectedProspect(null);
    } catch (error) {
      console.error('Erro ao excluir prospect:', error);
      toastError('Erro ao excluir prospect');
    } finally {
      setSaving(false);
    }
  };

  const getStatusVariant = (status: string): 'success' | 'warning' | 'danger' | 'default' => {
    switch (status) {
      case 'ganho':
        return 'success';
      case 'perdido':
        return 'danger';
      case 'proposta':
      case 'qualificado':
        return 'warning';
      default:
        return 'default';
    }
  };

  const columns = useMemo<ColumnDef<Prospect>[]>(
    () => [
      {
        accessorKey: 'nome',
        header: 'Nome',
        cell: (info) => (
          <button
            onClick={() => { setSelectedProspect(info.row.original); setDetalhesModalOpen(true); }}
            className="font-medium hover:underline text-left"
            style={{ color: 'var(--color-gold)' }}
          >
            {info.getValue() as string}
          </button>
        ),
      },
      {
        accessorKey: 'origem',
        header: 'Origem',
        cell: (info) => {
          const origem = info.getValue() as string;
          const option = origemOptions.find((o) => o.value === origem);
          const isLiberta = origem === 'liberta';
          return <span className={isLiberta ? 'px-2 py-1 rounded-full text-xs font-medium' : ''} style={isLiberta ? { backgroundColor: 'var(--color-success-bg)', color: 'var(--color-success)' } : undefined}>{option?.label || origem || '-'}</span>;
        },
      },
      {
        accessorKey: 'proximoContato',
        header: 'Prox. Contato',
        cell: (info) => {
          const data = info.getValue() as string;
          if (!data) return <span className="text-muted">-</span>;
          const hoje = new Date().toISOString().split('T')[0];
          const atrasado = data < hoje;
          const ehHoje = data === hoje;
          const hora = info.row.original.proximoContatoHora || '';
          return (
            <span className={`flex items-center text-sm ${atrasado ? 'danger font-semibold' : ehHoje ? 'warning font-semibold' : ''}`}>
              {atrasado && <AlertTriangle className="w-4 h-4 mr-1" />}
              {new Date(data + 'T00:00:00').toLocaleDateString('pt-BR')} {hora && `${hora}`}
            </span>
          );
        },
      },
      {
        accessorKey: 'potencial',
        header: 'Pipe Atual',
        cell: (info) => {
          const potencial = info.getValue() as number;
          const realizado = info.row.original.realizadoValor || 0;
          const pipeAtual = Math.max(0, potencial - realizado);
          const tipo = info.row.original.potencialTipo || 'captacao_liquida';
          const label = tipo === 'transferencia_xp' ? 'TXP' : 'CL';
          const excedeu = realizado > potencial;
          return (
            <span className={excedeu ? 'warning' : ''}>
              <CurrencyCell value={pipeAtual} /> <span className="text-xs text-muted">({label})</span>
              {excedeu && <span className="ml-1 text-xs px-1 rounded" style={{ backgroundColor: 'var(--color-warning-bg)', color: 'var(--color-warning)' }}>&gt;100%</span>}
            </span>
          );
        },
      },
      {
        accessorKey: 'realizadoValor',
        header: 'Realizado',
        cell: (info) => {
          const val = info.getValue() as number;
          if (!val) return <span className="text-muted">-</span>;
          const tipo = info.row.original.realizadoTipo || 'captacao_liquida';
          const label = tipo === 'transferencia_xp' ? 'TXP' : 'CL';
          return <span className="success"><CurrencyCell value={val} /> <span className="text-xs">({label})</span></span>;
        },
      },
      {
        accessorKey: 'status',
        header: 'Status',
        cell: (info) => {
          const status = info.getValue() as string;
          const option = statusOptions.find((s) => s.value === status);
          return <StatusBadge status={option?.label || status} variant={getStatusVariant(status)} />;
        },
      },
      {
        id: 'actions',
        header: 'Acoes',
        cell: (info) => (
          <ActionButtons
            onEdit={() => openModal(info.row.original)}
            onDelete={() => {
              setSelectedProspect(info.row.original);
              setDeleteModalOpen(true);
            }}
          />
        ),
      },
    ],
    [openModal]
  );

  const totais = useMemo(() => {
    const ativos = prospects.filter((p) => !['ganho', 'perdido'].includes(p.status));
    // Pipe Atual = max(0, potencial - realizado) -- pipe diminui com realizado
    const pipeAtualCL = ativos
      .filter((p) => p.potencialTipo !== 'transferencia_xp')
      .reduce((sum, p) => sum + Math.max(0, (p.potencial || 0) - (p.realizadoValor || 0)), 0);
    const pipeAtualTXP = ativos
      .filter((p) => p.potencialTipo === 'transferencia_xp')
      .reduce((sum, p) => sum + Math.max(0, (p.potencial || 0) - (p.realizadoValor || 0)), 0);
    // Realizado total (todos os prospects, nao so ativos)
    const realizadoCL = prospects.filter((p) => p.realizadoTipo !== 'transferencia_xp').reduce((sum, p) => sum + (p.realizadoValor || 0), 0);
    const realizadoTXP = prospects.filter((p) => p.realizadoTipo === 'transferencia_xp').reduce((sum, p) => sum + (p.realizadoValor || 0), 0);
    return {
      total: prospects.length,
      ativos: ativos.length,
      pipeAtualCL,
      pipeAtualTXP,
      pipeAtualTotal: pipeAtualCL + pipeAtualTXP,
      realizadoCL,
      realizadoTXP,
      realizadoTotal: realizadoCL + realizadoTXP,
      lembretes: lembretes.length,
    };
  }, [prospects, lembretes]);

  if (loading) {
    return <PageSkeleton showKpis kpiCount={6} />;
  }

  return (
    <div className="space-y-6">
      <PageHeader
        title="Prospects"
        subtitle="Pipeline de potenciais clientes"
        actions={
          <button
            onClick={() => openModal()}
            className="flex items-center px-4 py-2 rounded-md hover:brightness-110 focus-gold transition-colors"
            style={{ backgroundColor: 'var(--color-gold)', color: 'var(--color-text-inverse)' }}
          >
            <Plus className="w-5 h-5 mr-2" />
            Novo Prospect
          </button>
        }
        controls={
          <SavedViewsControl
            uid={user?.uid}
            scope="prospects"
            getSnapshot={getSavedViewSnapshot}
            applySnapshot={applySavedViewSnapshot}
            hasExplicitQuery={searchParams.toString().length > 0}
          />
        }
      />

      {/* Lembretes */}
      {lembretes.length > 0 && (
        <div className="rounded-lg p-4" style={{ backgroundColor: 'var(--color-warning-bg)', border: '1px solid var(--color-warning)' }}>
          <div className="flex items-center font-semibold mb-2" style={{ color: 'var(--color-warning)' }}><Bell className="w-5 h-5 mr-2" />Contatos pendentes ({lembretes.length})</div>
          <div className="flex flex-wrap gap-2">
            {lembretes.slice(0, 5).map((p) => (
              <button key={p.id} onClick={() => { setSelectedProspect(p); setDetalhesModalOpen(true); }} className="px-3 py-1 rounded-full text-sm" style={{ backgroundColor: 'var(--color-warning-bg)', color: 'var(--color-warning)' }}>{p.nome}</button>
            ))}
            {lembretes.length > 5 && <span className="text-sm" style={{ color: 'var(--color-warning)' }}>+{lembretes.length - 5} mais</span>}
          </div>
        </div>
      )}

      {/* KPIs - Pipe x Realizado */}
      <div className="grid grid-cols-2 md:grid-cols-6 gap-4">
        <div className="p-4 rounded-xl" style={{ backgroundColor: 'var(--color-surface)', border: '1px solid var(--color-border-subtle)', boxShadow: 'var(--shadow-sm)' }}>
          <p className="text-sm text-secondary">Ativos</p>
          <p className="text-2xl font-bold" style={{ color: 'var(--color-chart-4)' }}>{totais.ativos}</p>
        </div>
        <div className="p-4 rounded-xl" style={{ backgroundColor: 'var(--color-surface)', border: '1px solid var(--color-border-subtle)', boxShadow: 'var(--shadow-sm)', borderLeft: '4px solid var(--color-info)' }}>
          <p className="text-sm text-secondary">Pipe Atual</p>
          <p className="text-2xl font-bold" style={{ color: 'var(--color-info)' }}>{formatCurrency(totais.pipeAtualTotal)}</p>
        </div>
        <div className="p-4 rounded-xl" style={{ backgroundColor: 'var(--color-surface)', border: '1px solid var(--color-border-subtle)', boxShadow: 'var(--shadow-sm)' }}>
          <p className="text-sm text-secondary">Pipe CL</p>
          <p className="text-xl font-bold" style={{ color: 'var(--color-info)' }}>{formatCurrency(totais.pipeAtualCL)}</p>
        </div>
        <div className="p-4 rounded-xl" style={{ backgroundColor: 'var(--color-surface)', border: '1px solid var(--color-border-subtle)', boxShadow: 'var(--shadow-sm)' }}>
          <p className="text-sm text-secondary">Pipe TXP</p>
          <p className="text-xl font-bold" style={{ color: 'var(--color-chart-4)' }}>{formatCurrency(totais.pipeAtualTXP)}</p>
        </div>
        <div className="p-4 rounded-xl" style={{ backgroundColor: 'var(--color-surface)', border: '1px solid var(--color-border-subtle)', boxShadow: 'var(--shadow-sm)' }}>
          <p className="text-sm text-secondary">Realizado CL</p>
          <p className="text-xl font-bold" style={{ color: 'var(--color-success)' }}>{formatCurrency(totais.realizadoCL)}</p>
        </div>
        <div className="p-4 rounded-xl" style={{ backgroundColor: 'var(--color-surface)', border: '1px solid var(--color-border-subtle)', boxShadow: 'var(--shadow-sm)' }}>
          <p className="text-sm text-secondary">Realizado TXP</p>
          <p className="text-xl font-bold" style={{ color: 'var(--color-success)' }}>{formatCurrency(totais.realizadoTXP)}</p>
        </div>
      </div>

      <DataTable
        data={prospects}
        columns={columns}
        searchPlaceholder="Buscar prospects..."
        searchValue={tableSearch}
        onSearchChange={setTableSearch}
        sortingState={tableSorting}
        onSortingChange={setTableSorting}
      />

      <Modal
        isOpen={modalOpen}
        onClose={() => setModalOpen(false)}
        title={selectedProspect ? 'Editar Prospect' : 'Novo Prospect'}
        size="lg"
      >
        <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <Input
              label="Nome *"
              {...register('nome')}
              error={errors.nome?.message}
            />
            <Input
              label="CPF/CNPJ"
              {...register('cpfCnpj')}
              error={errors.cpfCnpj?.message}
            />
            <Input
              label="Email"
              type="email"
              {...register('email')}
              error={errors.email?.message}
            />
            <Input
              label="Telefone"
              {...register('telefone')}
              error={errors.telefone?.message}
            />
            <Select
              label="Origem"
              options={origemOptions}
              {...register('origem')}
              error={errors.origem?.message}
            />
            <Select
              label="Status"
              options={statusOptions}
              {...register('status')}
              error={errors.status?.message}
            />
            <Input
              label="Potencial (R$)"
              type="number"
              step="0.01"
              {...register('potencial', { valueAsNumber: true })}
              error={errors.potencial?.message}
            />
            <Select
              label="Tipo Potencial"
              options={tipoOptions}
              {...register('potencialTipo')}
            />
            <Input
              label="Probabilidade (%)"
              type="number"
              min="0"
              max="100"
              {...register('probabilidade', { valueAsNumber: true })}
              error={errors.probabilidade?.message}
            />
            <Input
              label="Data do Contato"
              type="date"
              {...register('dataContato')}
              error={errors.dataContato?.message}
            />
            <Input
              label="Proximo Contato"
              type="date"
              {...register('proximoContato')}
              error={errors.proximoContato?.message}
            />
            <Input
              label="Hora"
              type="time"
              {...register('proximoContatoHora')}
            />
          </div>

          {/* Realizado */}
          <div className="border-t pt-4 mt-4" style={{ borderColor: 'var(--color-border-subtle)' }}>
            <h4 className="font-medium mb-3" style={{ color: 'var(--color-text-muted)' }}>Realizado (quando convertido)</h4>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <Input
                label="Valor Realizado"
                type="number"
                step="0.01"
                {...register('realizadoValor', { valueAsNumber: true })}
              />
              <Select
                label="Tipo Realizado"
                options={tipoOptions}
                {...register('realizadoTipo')}
              />
              <Input
                label="Data Realizado"
                type="date"
                {...register('realizadoData')}
              />
            </div>
            {isWonSelected && !(Number(realizadoValorWatch || 0) > 0 && Boolean(realizadoDataWatch)) && (
              <p className="mt-2 text-sm" style={{ color: 'var(--color-danger)' }}>
                Status Ganho exige Valor Realizado maior que zero e Data Realizado.
              </p>
            )}
            {!isWonSelected && (Number(realizadoValorWatch || 0) > 0 || Boolean(realizadoDataWatch)) && (
              <p className="mt-2 text-sm" style={{ color: 'var(--color-warning)' }}>
                Defina status como Ganho para converter este prospect em cliente.
              </p>
            )}
          </div>

          <TextArea
            label="Observacoes"
            {...register('observacoes')}
            error={errors.observacoes?.message}
          />

          <div className="flex justify-end space-x-3 pt-4">
            <button
              type="button"
              onClick={() => setModalOpen(false)}
              className="px-4 py-2 text-sm font-medium rounded-md focus-gold"
              style={{ color: 'var(--color-text)', backgroundColor: 'var(--color-surface)', border: '1px solid var(--color-border)' }}
            >
              Cancelar
            </button>
            <button
              type="submit"
              disabled={saving}
              className="px-4 py-2 text-sm font-medium rounded-md hover:brightness-110 focus-gold disabled:opacity-50"
              style={{ backgroundColor: 'var(--color-gold)', color: 'var(--color-text-inverse)' }}
            >
              {saving ? 'Salvando...' : selectedProspect ? 'Atualizar' : 'Criar'}
            </button>
          </div>
        </form>
      </Modal>

      <ConfirmDialog
        isOpen={deleteModalOpen}
        onClose={() => setDeleteModalOpen(false)}
        onConfirm={handleDelete}
        title="Excluir Prospect"
        message="Tem certeza que deseja excluir este prospect? Esta acao nao pode ser desfeita."
        confirmText="Excluir"
        variant="danger"
        loading={saving}
      />

      {/* Modal de Detalhes do Prospect */}
      {selectedProspect && (
        <ProspectDetalhesModal
          isOpen={detalhesModalOpen}
          onClose={() => setDetalhesModalOpen(false)}
          prospect={selectedProspect}
          interacoes={interacoes.filter((i) => i.prospectId === selectedProspect.id)}
          onInteracaoSaved={(i) => setInteracoes((prev) => {
            const idx = prev.findIndex((x) => x.id === i.id);
            return idx >= 0 ? prev.map((x) => (x.id === i.id ? i : x)) : [...prev, i];
          })}
          onInteracaoDeleted={(id) => setInteracoes((prev) => prev.filter((x) => x.id !== id))}
        />
      )}
    </div>
  );
}

// ============== MODAL DE DETALHES DO PROSPECT ==============
interface DetalhesModalProps {
  isOpen: boolean;
  onClose: () => void;
  prospect: Prospect;
  interacoes: ProspectInteracao[];
  onInteracaoSaved: (i: ProspectInteracao) => void;
  onInteracaoDeleted: (id: string) => void;
}

function ProspectDetalhesModal({ isOpen, onClose, prospect, interacoes, onInteracaoSaved, onInteracaoDeleted }: DetalhesModalProps) {
  const { user } = useAuth();
  const [novaInteracao, setNovaInteracao] = useState({ tipo: 'ligacao', data: '', resumo: '' });
  const [saving, setSaving] = useState(false);

  const handleAddInteracao = async () => {
    if (!user || !prospect.id || !novaInteracao.data) return;
    try {
      setSaving(true);
      const created = await prospectInteracaoRepository.create({
        prospectId: prospect.id,
        tipo: novaInteracao.tipo as 'ligacao' | 'reuniao' | 'email' | 'whatsapp' | 'visita' | 'outro',
        data: novaInteracao.data,
        resumo: novaInteracao.resumo,
      }, user.uid);
      onInteracaoSaved(created);
      setNovaInteracao({ tipo: 'ligacao', data: '', resumo: '' });
      toastSuccess('Interacao adicionada!');
    } catch {
      toastError('Erro ao adicionar interacao');
    } finally {
      setSaving(false);
    }
  };

  const handleDeleteInteracao = async (id: string) => {
    if (!user) return;
    try {
      await prospectInteracaoRepository.delete(id, user.uid);
      onInteracaoDeleted(id);
      toastSuccess('Interacao excluida!');
    } catch {
      toastError('Erro ao excluir');
    }
  };

  const sortedInteracoes = [...interacoes].sort((a, b) => b.data.localeCompare(a.data));

  return (
    <Modal isOpen={isOpen} onClose={onClose} title={`Detalhes: ${prospect.nome}`} size="lg">
      <div className="space-y-6">
        {/* Info */}
        <div className="p-4 rounded-lg grid grid-cols-2 gap-3 text-sm" style={{ backgroundColor: 'var(--color-surface-2)' }}>
          <div><span className="text-muted">Origem:</span> <span className="font-medium">{origemOptions.find((o) => o.value === prospect.origem)?.label || prospect.origem || '-'}</span></div>
          <div><span className="text-muted">Status:</span> <span className="font-medium">{statusOptions.find((s) => s.value === prospect.status)?.label || prospect.status}</span></div>
          <div><span className="text-muted">Potencial:</span> <span className="font-medium">{formatCurrency(prospect.potencial || 0)} ({prospect.potencialTipo === 'transferencia_xp' ? 'TXP' : 'CL'})</span></div>
          <div><span className="text-muted">Realizado:</span> <span className="font-medium success">{formatCurrency(prospect.realizadoValor || 0)}</span></div>
          <div><span className="text-muted">Prox. Contato:</span> <span className="font-medium">{prospect.proximoContato ? new Date(prospect.proximoContato + 'T00:00:00').toLocaleDateString('pt-BR') : '-'} {prospect.proximoContatoHora || ''}</span></div>
          <div><span className="text-muted">Telefone:</span> <span className="font-medium">{prospect.telefone || '-'}</span></div>
          <div><span className="text-muted">Convertido:</span> <span className="font-medium">{prospect.converted ? 'Sim' : 'Nao'}</span></div>
        </div>

        {/* Nova Interacao */}
        <div className="pt-4" style={{ borderTop: '1px solid var(--color-border)' }}>
          <h4 className="font-semibold mb-3" style={{ color: 'var(--color-text)' }}>Adicionar Interacao</h4>
          <div className="flex flex-wrap gap-2 items-end">
            <select value={novaInteracao.tipo} onChange={(e) => setNovaInteracao({ ...novaInteracao, tipo: e.target.value })} className="px-3 py-2 rounded-md text-sm" style={{ border: '1px solid var(--color-border)', backgroundColor: 'var(--color-surface)' }}>
              {interacaoTipoOptions.map((o) => <option key={o.value} value={o.value}>{o.label}</option>)}
            </select>
            <input type="date" value={novaInteracao.data} onChange={(e) => setNovaInteracao({ ...novaInteracao, data: e.target.value })} className="px-3 py-2 rounded-md text-sm" style={{ border: '1px solid var(--color-border)', backgroundColor: 'var(--color-surface)' }} />
            <input type="text" placeholder="Resumo" value={novaInteracao.resumo} onChange={(e) => setNovaInteracao({ ...novaInteracao, resumo: e.target.value })} className="flex-1 min-w-[150px] px-3 py-2 rounded-md text-sm" style={{ border: '1px solid var(--color-border)', backgroundColor: 'var(--color-surface)' }} />
            <button onClick={handleAddInteracao} disabled={saving || !novaInteracao.data} className="px-4 py-2 rounded-md hover:brightness-110 focus-gold disabled:opacity-50 text-sm" style={{ backgroundColor: 'var(--color-gold)', color: 'var(--color-text-inverse)' }}>
              {saving ? 'Salvando...' : 'Adicionar'}
            </button>
          </div>
        </div>

        {/* Timeline de Interacoes */}
        <div className="pt-4" style={{ borderTop: '1px solid var(--color-border)' }}>
          <h4 className="font-semibold mb-3" style={{ color: 'var(--color-text)' }}>Historico de Contatos ({interacoes.length})</h4>
          {sortedInteracoes.length === 0 ? (
            <p className="text-muted text-sm">Nenhuma interacao registrada.</p>
          ) : (
            <div className="space-y-2 max-h-64 overflow-y-auto">
              {sortedInteracoes.map((i) => (
                <div key={i.id} className="flex items-start gap-3 p-3 rounded-lg group" style={{ backgroundColor: 'var(--color-surface-2)' }}>
                  <div style={{ color: 'var(--color-gold)' }}>{interacaoIcons[i.tipo] || <Bell className="w-4 h-4" />}</div>
                  <div className="flex-1">
                    <div className="flex items-center gap-2">
                      <span className="font-medium text-sm">{interacaoTipoOptions.find((o) => o.value === i.tipo)?.label || i.tipo}</span>
                      <span className="text-xs text-muted">{new Date(i.data + 'T00:00:00').toLocaleDateString('pt-BR')}</span>
                    </div>
                    {i.resumo && <p className="text-sm text-secondary mt-1">{i.resumo}</p>}
                  </div>
                  <button onClick={() => i.id && handleDeleteInteracao(i.id)} className="danger opacity-0 group-hover:opacity-100 text-xs">Excluir</button>
                </div>
              ))}
            </div>
          )}
        </div>

        <div className="flex justify-end pt-4" style={{ borderTop: '1px solid var(--color-border)' }}>
          <button onClick={onClose} className="px-4 py-2 text-sm font-medium rounded-md focus-gold" style={{ color: 'var(--color-text)', backgroundColor: 'var(--color-surface)', border: '1px solid var(--color-border)' }}>Fechar</button>
        </div>
      </div>
    </Modal>
  );
}

